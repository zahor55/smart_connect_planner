import React from "react"

import Character from "../character"

export default function Game() {
  return (
    <div>
      <Character />
    </div>
  )
}
