# smart_connect_planner
part of final project-arduino system architecture planner
